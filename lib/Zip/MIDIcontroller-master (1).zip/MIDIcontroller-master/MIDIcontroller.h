#ifndef MIDIcontroller_h
#define MIDIcontroller_h

#include "MIDIbutton.h"
#include "MIDIpot.h"
#include "MIDIenc.h"
#include "MIDIcapSens.h"
#include "MIDIdrum.h"
//Bounce, Flicker and Encoder libraries are also required

#endif

